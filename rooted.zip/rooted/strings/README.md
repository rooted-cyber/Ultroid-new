# Strings Analytics


| Code | Language | Translated | Remaining |
|----|-------|-------|---|
| en | English [English] | 494 | 0 |
| ar | Arabic [العربية] | 490 | 4 |
| az | Azerbaijan [Azərbaycan] | 490 | 4 |
| bn | Bengali [বাংলা] | 490 | 4 |
| cn | Chinese [简体中文] | 490 | 4 |
| es | Spanish [Español] | 490 | 4 |
| fa | Persian [Farsi] | 491 | 3 |
| fr | French [Français] | 490 | 4 |
| gu | Gujarati [ગુજરાતી] | 490 | 4 |
| hi | Hindi [हिंदी] | 489 | 5 |
| id | Indonesia [Indonesia] | 490 | 4 |
| it | Italian [italiano] | 490 | 4 |
| jp | Japanese [日本] | 490 | 4 |
| ka | Kannada [ಕನ್ನಡ] | 490 | 4 |
| ml | Malayalam [മലയാളം] | 490 | 4 |
| mr | Marathi [मराठी] | 491 | 3 |
| ms | Malay [Bahasa Melayu] | 494 | NULL |
| or | Odia [ଓଡିଆ] | 490 | 4 |
| pt-br | Português [Português] | 490 | 4 |
| ru | Russian [Русский] | 490 | 4 |
| si | sinhala [සිංහල] | 490 | 4 |
| ta | தமிழ் [தமிழ்] | 490 | 4 |
| tr | Turkish [Türk] | 490 | 4 |
| uz | Uzbekcha [Uzbekcha] | 490 | 4 |


If Strings are not present, Google Translation will be used to Translate them at time of Usage.